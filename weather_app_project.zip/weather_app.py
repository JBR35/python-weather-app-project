# weather_app.py

import requests

class WeatherApp:
    def __init__(self, api_key):
        self.api_key = api_key
        self.base_url = "https://api.openweathermap.org/data/2.5/weather"

    def get_weather(self, city):
        """Fetch weather data for a given city."""
        try:
            params = {
                'q': city,
                'appid': self.api_key,
                'units': 'metric'  # Celsius
            }
            response = requests.get(self.base_url, params=params)
            response.raise_for_status()
            data = response.json()

            weather_info = {
                'city': data['name'],
                'temperature': data['main']['temp'],
                'humidity': data['main']['humidity'],
                'condition': data['weather'][0]['description']
            }
            return weather_info
        except requests.exceptions.HTTPError as http_err:
            return {"error": f"HTTP error occurred: {http_err}"}
        except Exception as err:
            return {"error": f"Other error occurred: {err}"}

    def display_weather(self, city):
        """Fetch and print formatted weather details."""
        weather = self.get_weather(city)
        if "error" in weather:
            print(weather["error"])
        else:
            print(f"\n🌍 Weather in {weather['city']}:")
            print(f"🌡️ Temperature: {weather['temperature']}°C")
            print(f"💧 Humidity: {weather['humidity']}%")
            print(f"☁️ Condition: {weather['condition'].title()}\n")


if __name__ == "__main__":
    # 🔑 Replace with your own OpenWeather API key
    API_KEY = "YOUR_API_KEY_HERE"

    app = WeatherApp(API_KEY)

    while True:
        city = input("Enter city name (or 'exit' to quit): ").strip()
        if city.lower() == "exit":
            print("Exiting Weather App. Goodbye! 👋")
            break
        app.display_weather(city)
