# Weather App

A simple Python Weather Application that fetches and displays real-time weather data (temperature, humidity, and conditions) using the OpenWeather API.

## Features
- Fetches live weather data by city name.
- Displays temperature (°C), humidity (%), and weather condition.
- Handles errors (invalid city, API issues).
- Modular class-based design for easy enhancements.

## Requirements
- Python 3.x
- `requests` library (`pip install requests`)
- OpenWeather API key (get it from: https://openweathermap.org/api)

## Usage
1. Clone this repository or download the ZIP file.
2. Install dependencies:
   ```bash
   pip install requests
   ```
3. Replace `YOUR_API_KEY_HERE` in `weather_app.py` with your OpenWeather API key.
4. Run the app:
   ```bash
   python weather_app.py
   ```

## Example
```
Enter city name (or 'exit' to quit): London

🌍 Weather in London:
🌡️ Temperature: 15°C
💧 Humidity: 72%
☁️ Condition: Light Rain
```

---
Made with ❤️ in Python
